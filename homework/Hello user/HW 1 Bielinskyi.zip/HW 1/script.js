let n = prompt("Type your first name");
if (n == null || n == "") {
  alert("Your name is not valid.");
} 
else {
  alert("Hello, " + n + "! How are you?");
}
